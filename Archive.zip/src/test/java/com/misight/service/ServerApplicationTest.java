package com.misight.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MisightApplicationTests {

	@Test
	void contextLoads() {
	}

}

